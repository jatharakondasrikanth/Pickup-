package com.pickup.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF10243E)
private val Teal = Color(0xFF10BFA5)
private val Blue = Color(0xFF1688F8)
private val Bg = Color(0xFFF7FAFC)

data class Ride(val driver: String, val from: String, val to: String, val time: String, val price: Int, val seats: Int, val rating: String, val vehicle: String)

data class PostedRide(val from: String, val to: String, val time: String, val seats: Int, val contribution: Int)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { PickupApp() } }
}

@Composable fun PickupApp() {
    var tab by remember { mutableIntStateOf(0) }
    var screen by remember { mutableStateOf("home") }
    var selectedRide by remember { mutableStateOf<Ride?>(null) }
    val postedRides = remember { mutableStateListOf<PostedRide>() }
    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, secondary = Teal, background = Bg)) {
        when (screen) {
            "ride" -> RideSearchScreen(onBack={screen="home"}, onSelect={ selectedRide=it; screen="details" })
            "details" -> selectedRide?.let { RideDetailsScreen(it, onBack={screen="ride"}, onRequest={screen="requested"}) }
            "requested" -> RequestSentScreen(onDone={screen="home"})
            "post" -> PostRideScreen(onBack={screen="home"}, onPosted={ postedRides.add(it); screen="myrides" })
            "myrides" -> MyRidesScreen(postedRides, onBack={screen="home"})
            "profile" -> ProfileScreen(onBack={screen="home"})
            else -> Scaffold(bottomBar={BottomNav(tab){tab=it; screen=when(it){0->"home";1->"myrides";2->"post";else->"profile"}}}) { p -> HomeScreen(Modifier.padding(p), {screen="ride"}, {screen="post"}) }
        }
    }
}

@Composable fun HomeScreen(modifier: Modifier, onNeedRide:()->Unit, onGoing:()->Unit) {
    LazyColumn(modifier.fillMaxSize().background(Bg), contentPadding=PaddingValues(18.dp), verticalArrangement=Arrangement.spacedBy(16.dp)) {
        item { Text("pickup", fontSize=38.sp, fontWeight=FontWeight.ExtraBold, color=Navy); Text("Together on the way", color=Teal, fontWeight=FontWeight.SemiBold) }
        item { Text("Same Route", fontSize=32.sp, fontWeight=FontWeight.ExtraBold, color=Navy); Text("More People", fontSize=32.sp, fontWeight=FontWeight.ExtraBold, color=Teal); Text("Happier Journeys", fontSize=32.sp, fontWeight=FontWeight.ExtraBold, color=Navy); Text("Connect with travellers going the same way and make the journey better together.", color=Color.DarkGray, fontSize=16.sp) }
        item { Row(horizontalArrangement=Arrangement.spacedBy(12.dp), modifier=Modifier.fillMaxWidth()) { ActionCard("I need a ride","Find people going your way",Blue,onNeedRide,Icons.Default.PersonPin); ActionCard("I'm going that way","Share your ride",Teal,onGoing,Icons.Default.DirectionsCar) } }
        item { SearchCard(onNeedRide) }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceEvenly) { Feature("✓","Safe & Verified"); Feature("🛡","Trusted Trips"); Feature("₹","Share Costs"); Feature("♧","Eco Friendly") } }
    }
}

@Composable fun ActionCard(title:String, sub:String, color:Color, onClick:()->Unit, icon:androidx.compose.ui.graphics.vector.ImageVector) { Card(Modifier.weight(1f).height(165.dp).clickable{onClick()}, shape=RoundedCornerShape(24.dp), colors=CardDefaults.cardColors(containerColor=color.copy(alpha=.12f))) { Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.SpaceBetween) { Icon(icon,null,tint=color,modifier=Modifier.size(32.dp)); Text(title,fontWeight=FontWeight.Bold,fontSize=19.sp,color=Navy); Text(sub,color=Color.DarkGray); Icon(Icons.Default.ArrowForward,null,tint=color,modifier=Modifier.align(Alignment.End)) } } }
@Composable fun SearchCard(onSearch:()->Unit) { Card(shape=RoundedCornerShape(24.dp)) { Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) { Text("Quick Search",fontWeight=FontWeight.Bold,fontSize=20.sp); OutlinedButton(onClick=onSearch,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.LocationOn,null);Spacer(Modifier.width(8.dp));Text("From")}; OutlinedButton(onClick=onSearch,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Place,null);Spacer(Modifier.width(8.dp));Text("To")}; Button(onClick=onSearch,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp)){Text("Search Rides")}} } }
@Composable fun Feature(icon:String,text:String){Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.width(76.dp)){Text(icon,fontSize=25.sp);Text(text,fontSize=11.sp,color=Navy,fontWeight=FontWeight.SemiBold)}}
@Composable fun BottomNav(selected:Int,onSelect:(Int)->Unit){NavigationBar{listOf("Home" to Icons.Default.Home,"My Rides" to Icons.Default.Search,"Post Ride" to Icons.Default.AddCircle,"Profile" to Icons.Default.Person).forEachIndexed{i,item->NavigationBarItem(selected==i,{onSelect(i)},{Icon(item.second,null)},{},{Text(item.first)})}}}

@Composable fun RideSearchScreen(onBack:()->Unit,onSelect:(Ride)->Unit){
    var from by remember{mutableStateOf("")}; var to by remember{mutableStateOf("")}; var searched by remember{mutableStateOf(false)}
    val rides=listOf(Ride("Rohith Kumar","Karimnagar","Hyderabad","10:00 AM",250,2,"4.8","Maruti Baleno • TS 16 AB 1234"),Ride("Sneha Reddy","Karimnagar","Hyderabad","11:30 AM",300,3,"4.6","Hyundai i20 • TS 07 CD 5678"),Ride("Vikram","Karimnagar","Hyderabad","1:00 PM",280,1,"4.9","Kia Seltos • TS 09 EF 9012"))
    Column(Modifier.fillMaxSize().background(Bg).padding(18.dp)){Row(verticalAlignment=Alignment.CenterVertically){IconButton({onBack()}){Icon(Icons.Default.ArrowBack,"Back")};Text("Find a ride",fontSize=26.sp,fontWeight=FontWeight.Bold)}}
    Spacer(Modifier.height(12.dp)); OutlinedTextField(from,{from=it},Modifier.fillMaxWidth(),label={Text("From")},singleLine=true); Spacer(Modifier.height(8.dp)); OutlinedTextField(to,{to=it},Modifier.fillMaxWidth(),label={Text("To")},singleLine=true); Spacer(Modifier.height(10.dp)); Button({searched=true},Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp)){Text("Search matching rides")}
    if(searched){Spacer(Modifier.height(18.dp));Text("Matching rides",fontSize=21.sp,fontWeight=FontWeight.Bold);LazyColumn{items(rides){RideResult(it){onSelect(it)}}}}
}

@Composable fun RideResult(ride:Ride,onClick:()->Unit){Card(Modifier.fillMaxWidth().padding(vertical=6.dp).clickable{onClick()},shape=RoundedCornerShape(20.dp)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.AccountCircle,null,Modifier.size(48.dp),tint=Blue);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(ride.driver,fontWeight=FontWeight.Bold);Text("${ride.from} → ${ride.to}");Text("${ride.time} • ${ride.seats} seats • ${ride.rating} ★",color=Color.Gray,fontSize=12.sp);Text(ride.vehicle,color=Navy,fontSize=12.sp)};Text("₹${ride.price}",fontWeight=FontWeight.Bold,color=Blue,fontSize=18.sp)}}}

@Composable fun RideDetailsScreen(ride:Ride,onBack:()->Unit,onRequest:()->Unit){Column(Modifier.fillMaxSize().background(Bg).padding(18.dp)){Row(verticalAlignment=Alignment.CenterVertically){IconButton({onBack()}){Icon(Icons.Default.ArrowBack,"Back")};Text("Ride details",fontSize=26.sp,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(18.dp));Card(shape=RoundedCornerShape(24.dp)){Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text(ride.driver,fontSize=22.sp,fontWeight=FontWeight.Bold);Text("${ride.rating} ★ verified traveller",color=Teal);Text("${ride.from} → ${ride.to}",fontSize=20.sp,fontWeight=FontWeight.SemiBold);Text("Departure: ${ride.time}");Text("Vehicle: ${ride.vehicle}");Text("Available seats: ${ride.seats}");Text("Contribution: ₹${ride.price}",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Blue)}};Spacer(Modifier.weight(1f));Button({onRequest()},Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp)){Text("Request a seat",fontSize=17.sp)}}}

@Composable fun RequestSentScreen(onDone:()->Unit){Column(Modifier.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Icon(Icons.Default.CheckCircle,null,tint=Teal,modifier=Modifier.size(90.dp));Text("Request sent!",fontSize=30.sp,fontWeight=FontWeight.Bold,color=Navy);Text("The driver can now accept your seat request.",color=Color.Gray);Spacer(Modifier.height(24.dp));Button({onDone()},shape=RoundedCornerShape(18.dp)){Text("Back to pickup")}}}

@Composable fun PostRideScreen(onBack:()->Unit,onPosted:(PostedRide)->Unit){var from by remember{mutableStateOf("")};var to by remember{mutableStateOf("")};var time by remember{mutableStateOf("")};var seats by remember{mutableStateOf("1")};var contribution by remember{mutableStateOf("200")};Column(Modifier.fillMaxSize().background(Bg).padding(18.dp)){Row(verticalAlignment=Alignment.CenterVertically){IconButton({onBack()}){Icon(Icons.Default.ArrowBack,"Back")};Text("Post a Ride",fontSize=26.sp,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(14.dp));OutlinedTextField(from,{from=it},Modifier.fillMaxWidth(),label={Text("From")},singleLine=true);Spacer(Modifier.height(8.dp));OutlinedTextField(to,{to=it},Modifier.fillMaxWidth(),label={Text("To")},singleLine=true);Spacer(Modifier.height(8.dp));OutlinedTextField(time,{time=it},Modifier.fillMaxWidth(),label={Text("Date & time")},singleLine=true);Spacer(Modifier.height(8.dp));OutlinedTextField(seats,{seats=it.filter(Char::isDigit)},Modifier.fillMaxWidth(),label={Text("Available seats")},singleLine=true);Spacer(Modifier.height(8.dp));OutlinedTextField(contribution,{contribution=it.filter(Char::isDigit)},Modifier.fillMaxWidth(),label={Text("Contribution per seat (₹)")},singleLine=true);Spacer(Modifier.weight(1f));Button({onPosted(PostedRide(from.ifBlank{"Karimnagar"},to.ifBlank{"Hyderabad"},time.ifBlank{"Tomorrow 10:00 AM"},seats.toIntOrNull()?:1,contribution.toIntOrNull()?:200))},Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp)){Text("Post Ride")}}}

@Composable fun MyRidesScreen(posted:List<PostedRide>,onBack:()->Unit){Column(Modifier.fillMaxSize().background(Bg).padding(18.dp)){Row(verticalAlignment=Alignment.CenterVertically){IconButton({onBack()}){Icon(Icons.Default.ArrowBack,"Back")};Text("My Rides",fontSize=26.sp,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(12.dp));if(posted.isEmpty())Text("No rides posted yet. Tap Post Ride to create your first journey.",color=Color.Gray) else LazyColumn{items(posted){r->Card(Modifier.fillMaxWidth().padding(vertical=6.dp),shape=RoundedCornerShape(20.dp)){Column(Modifier.padding(16.dp)){Text("${r.from} → ${r.to}",fontWeight=FontWeight.Bold,fontSize=18.sp);Text(r.time);Text("${r.seats} seats • ₹${r.contribution} per seat",color=Teal)}}}}}}
@Composable fun ProfileScreen(onBack:()->Unit){Column(Modifier.fillMaxSize().background(Bg).padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){IconButton({onBack()}){Icon(Icons.Default.ArrowBack,"Back")};Text("Profile",fontSize=26.sp,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(28.dp));Icon(Icons.Default.AccountCircle,null,Modifier.size(100.dp),tint=Blue);Text("Pickup User",fontSize=24.sp,fontWeight=FontWeight.Bold,color=Navy);Text("✓ Verified traveller",color=Teal);Spacer(Modifier.height(20.dp));Text("Trust score 4.8 ★",fontSize=18.sp);Text("Trips completed: 12",color=Color.Gray)}}
